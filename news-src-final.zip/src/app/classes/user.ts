export class User {

    public userId:number
    public fullName:string
    public userName:string
    public emailId:string
    public password:string
    public dob:Date
    public isAdmin:boolean

    constructor() {}

}
