export class Likes {

    public likeId:number
    public userId:number
    public articleId:number

    constructor() {}
}
