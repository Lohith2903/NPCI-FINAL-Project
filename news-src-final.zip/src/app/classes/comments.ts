export class Comments {

    public commentId:number
    public userId:number
    public articleId:number
    public comment:string

    constructor() {}
}
