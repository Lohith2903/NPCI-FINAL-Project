export class Article {

    public articleId:number
    public title:string

    constructor() {}
}
