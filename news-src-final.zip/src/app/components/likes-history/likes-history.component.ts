import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-likes-history',
  templateUrl: './likes-history.component.html',
  styleUrls: ['./likes-history.component.css']
})
export class LikesHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
