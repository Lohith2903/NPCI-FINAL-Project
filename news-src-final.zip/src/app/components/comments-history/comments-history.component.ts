import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comments-history',
  templateUrl: './comments-history.component.html',
  styleUrls: ['./comments-history.component.css']
})
export class CommentsHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
